#include "get_next_line_bonus.h"

int				main(void)
{
	int			fd1;
	int			fd2;
	char		*line;
	int			res;

	fd1 = open("test.txt", O_RDONLY);
	fd2 = open("get_next_line.c", O_RDONLY);
	printf("fd1: %d\n", fd1);
	printf("fd2: %d\n", fd2);
	res = 1;
	while (1)
	{
		res = get_next_line(fd1, &line);
		if (res == 1)
		{
			printf("%s\n", line);
		}
		else if (res == -1)
		{
			printf("ERROR\n");
		}
		else
		{
			safe_free(&line);
			break ;
		}
		safe_free(&line);
	}
		while (1)
	{
		res = get_next_line(fd2, &line);
		if (res == 1)
		{
			printf("%s\n", line);
		}
		else if (res == -1)
		{
			printf("ERROR\n");
		}
		else
		{
			safe_free(&line);
			break ;
		}
		safe_free(&line);
	}
	return (0);
}
